﻿namespace Models;

public class Data
{
    public string? Label { get; init; }
    public List<double> Vector { get; init; } = new();
}


