﻿
namespace Models;

public class DataSet
{
    public int? VectorSize { get; set; }

    public List<Data> Data { get; set; } = new();

}